// JavaScript Document
$(function () {
	$('[data-toggle="tooltip"]').tooltip();
});

