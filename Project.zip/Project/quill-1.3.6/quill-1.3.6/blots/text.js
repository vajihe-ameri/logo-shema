import Parchment from 'parchment';

class TextBlot extends Parchment.Text { }

export default TextBlot;
